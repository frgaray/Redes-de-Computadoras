(defproject graph "0.1.0-SNAPSHOT"
  :description "Gráficas"
  :dependencies [[org.clojure/clojure "1.10.1"]]
  :repl-options {:init-ns graph.core}
  :main graph.core/init)
