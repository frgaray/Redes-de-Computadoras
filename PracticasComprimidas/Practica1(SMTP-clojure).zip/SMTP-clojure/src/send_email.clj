(ns send-email
  (:require
   [postal.core :refer [send-message]]
   [email-password :refer [pass]]))

;; SMTP usage example
(defn send-me-an-email! [opts]
  (send-message {:host "smtp.gmail.com"
                 :user "your gmail address"
                 :pass pass
                 :port 587
                 :tls  true}
                {:from    "your gmail address"
                 :to      ["another address"]
                 :subject "Subject"
                 :body    [{:type    "text/html"
                            :content "<html>\n\t<head>\n\t\t<title>NeverSSL - helping you get online</title>\n\n\t\t<style>\n\t\tbody {\n\t\t\tfont-family: Montserrat, helvetica, arial, sans-serif; \n\t\t\tfont-size: 16x;\n\t\t\tcolor: #444444;\n\t\t\tmargin: 0;\n\t\t}\n\t\th2 {\n\t\t\tfont-weight: 700;\n\t\t\tfont-size: 1.6em;\n\t\t\tmargin-top: 30px;\n\t\t}\n\t\tp {\n\t\t\tline-height: 1.6em;\n\t\t}\n\t\t.container {\n\t\t\tmax-width: 650px;\n\t\t\tmargin: 20px auto 20px auto;\n\t\t\tpadding-left: 15px;\n\t\t\tpadding-right: 15px\n\t\t}\n\t\t.header {\n\t\t\tbackground-color: #42C0FD;\n\t\t\tcolor: #FFFFFF;\n\t\t\tpadding: 10px 0 10px 0;\n\t\t\tfont-size: 2.2em;\n\t\t}\n\t\t<!-- CSS from Mark Webster https://gist.github.com/markcwebster/9bdf30655cdd5279bad13993ac87c85d -->\n\t\t</style>\n\t</head>\n\t<body>\n\n\t<div class=\"header\">\n\t\t<div class=\"container\">\n\t\t<h1>NeverSSL</h1>\n\t\t</div>\n\t</div>\n\t\n\t<div class=\"content\">\n\t<div class=\"container\">\n\n\t<h2>What?</h2>\n\t<p>This website is for when you try to open Facebook, Google, Amazon, etc\n\ton a wifi network, and nothing happens. Type \"http://neverssl.com\"\n\tinto your browser's url bar, and you'll be able to log on.</p>\n\n\t<h2>How?</h2>\n\t<p>neverssl.com will never use SSL (also known as TLS). No\n\tencryption, no strong authentication, no <a\n\thref=\"https://en.wikipedia.org/wiki/HTTP_Strict_Transport_Security\">HSTS</a>,\n\tno HTTP/2.0, just plain old unencrypted HTTP and forever stuck in the dark\n\tages of internet security.</p> \n\n\t<h2>Why?</h2>\n\t<p>Normally, that's a bad idea. You should always use SSL and secure\n\tencryption when possible. In fact, it's such a bad idea that most websites\n\tare now using https by default.</p>\n\t\n\t<p>And that's great, but it also means that if you're relying on\n\tpoorly-behaved wifi networks, it can be hard to get online.  Secure\n\tbrowsers and websites using https make it impossible for those wifi\n\tnetworks to send you to a login or payment page. Basically, those networks\n\tcan't tap into your connection just like attackers can't. Modern browsers\n\tare so good that they can remember when a website supports encryption and\n\teven if you type in the website name, they'll use https.</p> \n\n\t<p>And if the network never redirects you to this page, well as you can\n\tsee, you're not missing much.</p>\n\n\t<a href=\"https://twitter.com/neverssl\">Follow @neverssl</a>\n\n\t</div>\n\t</div>\n\t</body>\n</html>"}]}))

