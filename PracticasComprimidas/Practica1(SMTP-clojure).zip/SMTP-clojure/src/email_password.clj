(ns email-password)

(def pass "Aquí va tu password")
